const USER_SHEET = "Users";

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const action = data.action;

    if (action === "login") {
      return json(login(data.username, data.password));
    }

    if (action === "changePassword") {
      return json(changePassword(data.username, data.oldPassword, data.newPassword));
    }

    if (action === "listUsers") {
      return json(listUsers(data.requester));
    }

    if (action === "adminResetPassword") {
      return json(adminResetPassword(data.requester, data.targetUsername, data.newPassword));
    }

    return json({ success: false, error: "Unknown action" });

  } catch (err) {
    return json({ success: false, error: err.message });
  }
}

function json(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function getUserSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(USER_SHEET);

  if (!sheet) {
    sheet = ss.insertSheet(USER_SHEET);
    sheet.appendRow(["username", "password", "role", "display_name"]);
    sheet.appendRow(["admin", "admin123", "admin", "Admin"]);
    sheet.appendRow(["C001", "pw001", "shop", "ร้าน C001"]);
    sheet.appendRow(["C002", "pw002", "shop", "ร้าน C002"]);
    sheet.appendRow(["C003", "pw003", "shop", "ร้าน C003"]);
  }

  return sheet;
}

function getUsersData() {
  const sheet = getUserSheet();
  const values = sheet.getDataRange().getValues();
  const headers = values[0];

  const users = [];

  for (let i = 1; i < values.length; i++) {
    if (!values[i][0]) continue;

    users.push({
      row: i + 1,
      username: String(values[i][0]),
      password: String(values[i][1]),
      role: String(values[i][2]),
      displayName: String(values[i][3])
    });
  }

  return users;
}

function findUser(username) {
  const users = getUsersData();
  return users.find(u => u.username === username);
}

function login(username, password) {
  const user = findUser(username);

  if (!user) {
    return { success: false, error: "ไม่พบ username นี้" };
  }

  if (user.password !== password) {
    return { success: false, error: "password ไม่ถูกต้อง" };
  }

  return {
    success: true,
    user: {
      username: user.username,
      role: user.role,
      displayName: user.displayName
    }
  };
}

function changePassword(username, oldPassword, newPassword) {
  const sheet = getUserSheet();
  const user = findUser(username);

  if (!user) {
    return { success: false, error: "ไม่พบ user" };
  }

  if (user.password !== oldPassword) {
    return { success: false, error: "รหัสผ่านเดิมไม่ถูกต้อง" };
  }

  sheet.getRange(user.row, 2).setValue(newPassword);

  return { success: true };
}

function listUsers(requester) {
  const requesterUser = findUser(requester);

  if (!requesterUser || requesterUser.role !== "admin") {
    return { success: false, error: "เฉพาะ admin เท่านั้น" };
  }

  const users = getUsersData().map(u => ({
    username: u.username,
    role: u.role,
    displayName: u.displayName
  }));

  return { success: true, users };
}

function adminResetPassword(requester, targetUsername, newPassword) {
  const sheet = getUserSheet();
  const requesterUser = findUser(requester);

  if (!requesterUser || requesterUser.role !== "admin") {
    return { success: false, error: "เฉพาะ admin เท่านั้น" };
  }

  const target = findUser(targetUsername);

  if (!target) {
    return { success: false, error: "ไม่พบร้านค้านี้" };
  }

  if (target.role !== "shop") {
    return { success: false, error: "เปลี่ยนได้เฉพาะ user ร้านค้า" };
  }

  sheet.getRange(target.row, 2).setValue(newPassword);

  return { success: true };
}
